  
                                        
                                                                 
                                                               
                                 
                               
  
                      


  
                                                 
  
var g_ActiveTournamentInfo =
{
	eventid: 19,
	organization: 'pgl',
	location: 'antwerp2022',
	stickerid_graffiti: 5395,
	itemid_pass: 4825,
	itemid_coins: [
		4826, 4827, 4828, 4829
	],
	itemid_pack: 4830,
	itemid_charge: 4831,
	active: false,
};


  
                                                       
  
var g_ActiveTournamentTeams =
[
	         
	{
		teamid: 95,
		team: 'hero',
		stickerid_graffiti: 5371,
		team_group: 'legends',
	},
	                    
	{
		teamid: 101,
		team: 'cope',
		stickerid_graffiti: 5372,
		team_group: 'legends',
	},
	      
	{
		teamid: 69,
		team: 'big',
		stickerid_graffiti: 5373,
		team_group: 'legends',
	},
	         
	{
		teamid: 33,
		team: 'c9',
		stickerid_graffiti: 5374,
		team_group: 'legends',
	},
	        
	{
		teamid: 85,
		team: 'furi',
		stickerid_graffiti: 5375,
		team_group: 'legends',
	},
	            
	{
		teamid: 61,
		team: 'faze',
		stickerid_graffiti: 5376,
		team_group: 'legends',
	},
	                    
	{
		teamid: 1,
		team: 'nip',
		stickerid_graffiti: 5377,
		team_group: 'legends',
	},
	                
	{
		teamid: 12,
		team: 'navi',
		stickerid_graffiti: 5378,
		team_group: 'legends',
	},
	       
	{
		teamid: 84,
		team: 'ence',
		stickerid_graffiti: 5379,
		team_group: 'challengers',
	},
	             
	{
		teamid: 59,
		team: 'g2',
		stickerid_graffiti: 5380,
		team_group: 'challengers',
	},
	                
	{
		teamid: 90,
		team: 'forz',
		stickerid_graffiti: 5381,
		team_group: 'challengers',
	},
	           
	{
		teamid: 60,
		team: 'astr',
		stickerid_graffiti: 5382,
		team_group: 'challengers',
	},
	           
	{
		teamid: 89,
		team: 'vita',
		stickerid_graffiti: 5383,
		team_group: 'challengers',
	},
	       
	{
		teamid: 80,
		team: 'mibr',
		stickerid_graffiti: 5384,
		team_group: 'challengers',
	},
	                   
	{
		teamid: 113,
		team: 'imp',
		stickerid_graffiti: 5385,
		team_group: 'challengers',
	},
	                  
	{
		teamid: 114,
		team: 'bne',
		stickerid_graffiti: 5386,
		team_group: 'challengers',
	},
	               
	{
		teamid: 110,
		team: 'eter',
		stickerid_graffiti: 5387,
		team_group: 'contenders',
	},
	              
	{
		teamid: 81,
		team: 'spir',
		stickerid_graffiti: 5388,
		team_group: 'contenders',
	},
	            
	{
		teamid: 109,
		team: 'out',
		stickerid_graffiti: 5389,
		team_group: 'contenders',
	},
	                    
	{
		teamid: 111,
		team: 'cplx',
		stickerid_graffiti: 5390,
		team_group: 'contenders',
	},
	              
	{
		teamid: 108,
		team: 'ihc',
		stickerid_graffiti: 5391,
		team_group: 'contenders',
	},
	            
	{
		teamid: 53,
		team: 'ren',
		stickerid_graffiti: 5392,
		team_group: 'contenders',
	},
	              
	{
		teamid: 48,
		team: 'liq',
		stickerid_graffiti: 5393,
		team_group: 'contenders',
	},
	          
	{
		teamid: 112,
		team: 'nine',
		stickerid_graffiti: 5394,
		team_group: 'contenders',
	},
];


  
                                                             
  

var g_ActiveTournamentStoreLayout =
[
	[
	g_ActiveTournamentInfo.itemid_pass,
	g_ActiveTournamentInfo.itemid_pack,
	'#CSGO_TournamentPass_antwerp2022_pack_tinyname'
	],
	[
	4832,                                
	4842,                                  
	'#CSGO_crate_store_pack_antwerp2022_legends_groupname'
	],
	[
	4833,                                    
	4843,                                      
	'#CSGO_crate_store_pack_antwerp2022_challengers_groupname'
	],
	[
	4834,                                   
	4844,                                     
	'#CSGO_crate_store_pack_antwerp2022_contenders_groupname'
	],
	[
	4845,                                    
	'#CSGO_crate_store_pack_antwerp2022_signatures_groupname'
	],
];

var g_ActiveTournamentPasses =
[
	g_ActiveTournamentInfo.itemid_pass,
	g_ActiveTournamentInfo.itemid_pack,
];


  
                                                   
  
